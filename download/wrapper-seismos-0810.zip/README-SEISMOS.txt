================================================================
 СЕЙМОС: комплект автономного деплоя seismos.ru (обёртка v2 pro)
 Выдал Ибро по приказу Бро, 08.10.2026. Эталон семьи = та же
 обёртка, что у Старого Мастера (iznaki), МКТУ, Атороса и Наи.
================================================================

ЧТО ЭТО
-------
git_ssh_wrapper_pro.py — GIT_SSH-обёртка на paramiko (v2,
«двунаправленная прокачка»). Нужна, потому что в песочнице нет
ssh-бинарника, а порт 22 наружу закрыт: git ходит на
ssh.github.com:443 через эту обёртку. Push не виснет: stdout и
stderr качают фоновые потоки, stdin льётся порциями.

Шаг 0. САМОПРОВЕРКА ФАЙЛОВ (после распаковки)
---------------------------------------------
  sha256sum git_ssh_wrapper_pro.py
  Должно быть:
  8289a06fc1f11f2f10f7c4504f006d44db3f7421601d149a079df160bcce04f8

Твой ключ robot-seismos — ВНИЗУ ЭТОГО ФАЙЛА (блок «КЛЮЧ»),
выдан 08.10.2026 вместе с пакетом:
  sha256 = cea4ed6eafaee8b3aae9ad2bc298595857aba396d9c6ee128511091ffeb21dae
  (419 байт; сверь после копипаста)
Deploy key в репо seismos: id 165788547, право на запись.

Шаг 1. PARAMIKO
---------------
  pip install paramiko

Шаг 2. КЛЮЧ — В ДВА МЕСТА (железное правило)
--------------------------------------------
  mkdir -p ~/keys && cp robot-seismos.txt ~/keys/robot-seismos
  chmod 600 ~/keys/robot-seismos
  И СРАЗУ сохрани копию во ВТОРОМ месте своей среды:
  песочница перезапускается, ~/.ssh и ~/keys пустеют
  (26.09 у Атороса из-за этого «пропадал» ключ).

Шаг 3. ОБЁРТКА — В СИСТЕМУ
--------------------------
  chmod +x git_ssh_wrapper_pro.py
  export GIT_SSH=/полный/путь/git_ssh_wrapper_pro.py
  export GIT_SSH_KEY=/полный/путь/robot-seismos
  export GIT_SSH_VARIANT=ssh        # ОБЯЗАТЕЛЬНО: без этого git
                                    # падает «ssh variant 'simple'
                                    # does not support setting port»
  (экспорты — в каждый новый терминал, или в свой env-файл)

Шаг 4. REMOTE — ТОЛЬКО ЧЕРЕЗ 443
--------------------------------
  cd <твоя локальная копия seismos>
  git remote set-url origin ssh://git@ssh.github.com:443/gabbardtools-a11y/seismos.git

  Почему так: обёртка умеет порт (-p), а git сам подставит его
  из URL. Голый github.com:22 из песочницы НЕ стучится (ufw).

Шаг 5. ТЕСТ (без пуша)
----------------------
  git ls-remote origin
  Список рефов = ключ жив (auth на ssh.github.com:443 уже
  проверен Ибро 08.10: AUTH OK).
  git fetch origin

Шаг 6. РАБОЧИЙ ЦИКЛ
-------------------
  git fetch origin
  git rebase origin/main      # если пуш отклонён — СНАЧАЛА это
  git push --no-thin origin HEAD:main

  Деплой seismos.ru — АВТОМАТИЧЕСКИЙ ПО PUSH: workflow
  «Deploy seismos» (deploy.yml) собирает билд на раннере GitHub
  и rsync-ает на VPS сам. Кнопку жать НЕ надо. Следи за раном в
  Actions репо; прод проверяй: https://seismos.ru (HTTP 200).

ЖЕЛЕЗНЫЕ ПРАВИЛА
----------------
 1. НИКОГДА не делай git push --force / -f. 26.09 форс-пуш
    снёс историю workflow у всего семьи — урок в ДОПОЛНЕНИЕ-№1.
 2. Push отклонён? Не паникуй: git fetch origin && git rebase
    origin/main, затем пуш снова. Твои локальные коммиты
    сохранятся поверх чужих.
 3. git init с нуля = ЗАПРЕЩЁН на живом репо (теряется история).
 4. Ключ и обёртка — всегда в двух местах. После рестарта
    песочницы восстанови из второго места и повтори Шаги 1/3.
 5. Сервер (VPS) — зона Ибро. Твоя зона: код, пуш, проверка
    прода и ранов Actions.

sha256 КОНТРОЛЬНЫЕ СУММЫ
------------------------
  git_ssh_wrapper_pro.py : 8289a06fc1f11f2f10f7c4504f006d44db3f7421601d149a079df160bcce04f8
  robot-seismos (ключ)   : cea4ed6eafaee8b3aae9ad2bc298595857aba396d9c6ee128511091ffeb21dae

================================================================
КЛЮЧ (сохрани как robot-seismos, chmod 600; sha256 выше)
================================================================

-----BEGIN OPENSSH PRIVATE KEY-----
b3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtzc2gtZW
QyNTUxOQAAACCMRZHMDRGM4Yp3/OPErtIHQrrXWvsL1RiZ5MkkyHq4IAAAAKCAp+nhgKfp
4QAAAAtzc2gtZWQyNTUxOQAAACCMRZHMDRGM4Yp3/OPErtIHQrrXWvsL1RiZ5MkkyHq4IA
AAAECDH+B54k67VHf/VLQ3VXnHCi5F2VAbO15eIzvH7VjstIxFkcwNEYzhinf848Su0gdC
utda+wvVGJnkySTIerggAAAAGHJvYm90LXNlaXNtb3NAc2Vpc21vcy5ydQECAwQF
-----END OPENSSH PRIVATE KEY-----
